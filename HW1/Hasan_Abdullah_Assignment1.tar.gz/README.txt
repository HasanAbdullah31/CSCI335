i. Parts of assignment that were completed: all parts were completed.

ii. Any bugs that were encountered: no bugs were encountered.

iii. To run this program, do the following on a terminal:
     -To delete executables and object files, type:
        make clean
     -To compile, type:
        make all
     -To run the executable normally, type:
        ./test_chain
     ***There are 4 instances where the program requires user input; the inputs
        MUST be of the following format (else, the program will abort!):
	  [<a positive integer, n>: <item_1> <item_2> <...> <item_n>]
	The first 2 inputs require the items to be integers; if the items are
	of another type, you will get different results (e.g. typing 3.14 will
	be interpretted as 3, and typing a word will be interpretted as 0).
	The last 2 inputs require the items to be strings, so go wild.***
     -To run the executable with a valid input file, type:
        ./test_chain < file_name.txt

iv. Input files: test_input_file.txt
    Output files: None
