Author: Hasan Abdullah
Purpose: CSCI 335 Project 5

i. Parts of assignment that were completed: all parts were completed, including
                                            the extra credit part.

ii. Any bugs that were encountered: no bugs were encountered.

iii. To run this program, do the following on a terminal:
     -To delete executables and object files, type:
        make clean
     -To compile everything, type:
        make all
     -To run the executable, type:
        ./optimal_multiplications <dimensions_file>
           e.g.: ./optimal_multiplications dimensions_file.txt

        ***<dimensions_file> assumed to be of the correct format.***

iv. Input files: dimensions_file.txt
    Output files: None
